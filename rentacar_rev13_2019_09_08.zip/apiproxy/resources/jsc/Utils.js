"use strict";
/**
*** Facef
*** Script: funções utilitarias
*** Data: 17/08/2019
*** Autor: Marcelo Felix Salgado
**/
context.setVariable("utils_version", "1.1.1");

function isEmpty(value) {
    if (value === undefined || value === null) {
        return true;
    }

    if (value instanceof Array) {
        return value.length === 0;
    }

    value = value.toString();
    //return value.replace(/^\s+|\s+$/g, "") === "";
    return trim(value) === "";
}

function trim(str) {
    str = "" + str;
    return str.replace(/^\s+|\s+$/g, "");
}

function listProperties(obj) {
    var properties = [];
    var property = null;
    for (property in obj) {
        properties[properties.length] = property.toString();
    }
    return properties;
}

function setVariableObjectPropertyValue(obj, prefix) {
    var pv = listPropertyValue(obj, "", {});
    for (var property in pv) {
        context.setVariable(prefix + "." + property.toString(), pv[property.toString()]);
    }
}

function listPropertyValue(obj, prefix, properties) {
    for (var property in obj) {
        var p = prefix + property;
        if (typeof obj[property.toString()] == "object") {
            properties = listPropertyValue(obj[property.toString()], p + ".",
            properties);
        } else {
            properties[p] = obj[property.toString()];
        }
    }
    
    return properties;
}

function isNumber(str) {
    if (isEmpty(str)) {
        return false;
    }
    
    return new RegExp("^[-]?(\\d{1,}|\\d{1,}[.]|\\d{1,}[.]\\d{1,}|[.]\\d{1,})$").test(str.toString());
}