var _errorCode = context.getVariable("errorCode");
var _status = error.status.code;

if (_status == 404 && _errorCode == null) {
    context.setVariable("developerMessage", "\"Resource not found\"");
    context.setVariable("userMessage", "Resource not found");
    context.setVariable("errorCode", 20001);  
}