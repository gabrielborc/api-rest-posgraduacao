context.setVariable("developerMessage", null);
context.setVariable("userMessage", null);
context.setVariable("errorCode", null);
main();
function main() {
    var contentType = context.getVariable("request.header.Content-Type");
    
    if (isEmpty(contentType)) {
        context.setVariable("developerMessage", "\"Missing header parameter Content-Type\"");
        context.setVariable("userMessage", "Field Content-Type is required and can not be empty");
        context.setVariable("errorCode", 20001);
        return;
    } else if (contentType.toLowerCase().indexOf("application/json") == -1) {
        context.setVariable("developerMessage", "\"Invalid header parameter Content-Type - it must be filled with a value inner (application/json)\"");
        context.setVariable("userMessage", "Invalid field Content-Type - it must be filled with a value inner (application/json)");
        context.setVariable("errorCode", 20018);
        return;
    }
    
    var requestContent = context.getVariable("request.content");
    
    if (isEmpty(requestContent)) {
        context.setVariable("developerMessage", "\"Missing request body\"");
        context.setVariable("userMessage", "Missing all required fields");
        context.setVariable("errorCode", 20019);
        return;
    }
    
    try {
        requestContent =
        JSON.parse(context.getVariable("request.content"));
    } catch (err) {
        context.setVariable("developerMessage", "\"Malformed request body\"");
        context.setVariable("userMessage", "Malformed request body");
        context.setVariable("errorCode", 20020);
        return;
    }
    
    //validateRequestBody(requestContent);
    //setVariableObjectPropertyValue(requestContent, "requestContent");
}